// INSERT YOUR SIGNATURE HASH (v''v)
module.exports = {
  signature_hash: "YOUR SIGNATURE_HASH HERE"
};